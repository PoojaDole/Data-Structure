
public class StackClass {

	private int []arr;
	private int top;
	
	public StackClass()
	{
		this.arr=new int [5];
		this.top=-1;
	}
	
	public void push(int data)
	{
		if(this.top==-1)
		{
			this.top++;
			arr[this.top]=data;
		}
		else if(this.top>=0 && this.top<arr.length)
		{
			this.top++;
			arr[this.top]=data;
		}
		else
		{
			System.out.println("Stack Overflow");
		}
	}
}
