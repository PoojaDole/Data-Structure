import java.util.Scanner;
public class Pattern5 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter no of row");
		int n=sc.nextInt();
		int a=0;
		fun(a,n);
		sc.close();
	}
	public static void fun(int x,int n)
	{
		if(x<n)
		{
			x++;
			fun(x,n);
			for(int i=0;i<x;i++)
			{
				System.out.print("*"+" ");
			}
			
		}
		
		System.out.println();
	}
}
