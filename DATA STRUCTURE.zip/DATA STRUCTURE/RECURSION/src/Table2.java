import java.util.Scanner;

public class Table2 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("enter  table no:");
		int n=sc.nextInt();
		int a=1;
		fun(a,n);
		sc.close();
	}

	private static void fun(int x,int m) {
		
		if(x<=10)
		{
			System.out.println(m+" * "+x+" : "+m*x++);
			fun(x,m);
		}
	}
}
