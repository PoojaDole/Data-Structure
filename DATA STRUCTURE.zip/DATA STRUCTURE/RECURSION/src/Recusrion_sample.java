
public class Recusrion_sample {

	public static void main(String[] args) {
		int a=0;
		fun(a);
		
	}
	public static void fun(int x)
	{
		x++;
		System.out.print(x+" ");
		if(x<5)
		{
			fun(x);
			System.out.print(x+" ");
			
		}

		
		
	}
	
	
}
