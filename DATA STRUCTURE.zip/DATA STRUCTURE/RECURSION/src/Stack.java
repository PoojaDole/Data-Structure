
public class Stack {
	static 	int []arr=new int [5];
	static int top=-1;
	public static void main(String[] args) {
	
		push(10);
		push(20);
		push(30);
		push(40);
		push(50);
	
		peek();
		pop();
		peek();
	
	}
	public static void peek()
	{
		if(top==-1)
		{
			System.out.println("Stack is empty");
		}
		else
		{
			System.out.println("Stack element is: ");
			
			for(int i=top;i>=0;i--)
			{
				System.out.print(arr[i]+" ");
			}
		}
		System.out.println();
	}
	public static void push(int data)
	{
		if(top<arr.length-1)
		{
			top++;
			arr[top]=data;
			
		}
		else
		{
			System.out.println("stack overflow");
		}
			
	}
	public static void pop()
	{
		if(top>-1)
		{
			System.out.println("Deleted element is "+ arr[top]);
			top--;
		}
		else
		{
			System.out.println("stack underflow");
		}
	}
}
