
public class CharStack {
 static char []arr = new char[5];
 static int top=-1;
	public static void main(String[] args) {
	
		push('C');
		push('A');
		push('D');
		push('R');
		push('Z');
		pop();
		pop();
		peek();
	}
	public static void peek()
	{
		if(top==-1)
		{
			System.out.println("Stack Empty");
		}
	else
	{

		System.out.println("STACK ELEMENTS: ");
		for(int i=top;i>=0;i--)
		{
			System.out.print(arr[i]+" ");
		}
	}
		System.out.println();
	}
	private static void push(char c) {
		if(!check_stack_full())
		{
			top++;
			arr[top]=c;
		
			
		}
		else
		{
			System.out.println("Stack overflow");
		}
	}
	public static void pop()
	{
		if(!check_stack_empty())
		{
			System.out.println("Deleted element is "+arr[top]);
			top--;
		}
		else
		{
			System.out.println("STACK UNDERFLOW");
		}
	}
	public static boolean check_stack_empty()
	{
		if(top<0)
		{
			return true;
		}
	
		return false;
	}
	private static boolean check_stack_full() {
		
		if(top>arr.length-2)
			return true;
	
			return false;
	}

}
