
public class LinkedList {
	
	Node head;
	LinkedList()
	{
		this.head=null;
	}
	LinkedList(Node head)
	{
		this.head=null;
	}
	public void append(String data)
	{
		Node newnode=new Node(data);
		if(head==null)
		{
			head=newnode;
		}
		else
		{
			Node it=head;
			while(it.next!=null)
			{
				it=it.next;
			}
			it.next=newnode;
			newnode.next=null;
		}
	}
//	public void delete_by_position();
	public void delete_by_value(String data)
	{
		Node it=head;
		int c=0;;
		int gl=1;
		while(it!=null)
		{
			if(it.data.equals(data))
			{
				
//				delete_by_position(c);
				c++;
			}
			
		}
	}
	
}
