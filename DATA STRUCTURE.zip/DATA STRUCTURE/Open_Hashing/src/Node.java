
public class Node {

	String data;
	Node next;
	
	Node(String data)
	{
		this.next=null;
		this.data=data;
	}
	
	
	Node(String data,Node next)
	{
		this.next=next;
		this.data=data;
	}


	public String getData() {
		return data;
	}


	public void setData(String data) {
		this.data = data;
	}


	public Node getNext() {
		return next;
	}


	public void setNext(Node next) {
		this.next = next;
	}
	public String toString()
	{
		String str=" ";
		str= data+" ,";
		return str;
	}
	
	
}
