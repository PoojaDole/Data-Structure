
public class Queue {

	private int arr[];
	private int rear;
	private int front;
	
	Queue(int size)
	{
		this.arr=new int[size];
		this.rear=-1;
		this.front=-1;
		
	}
	public String toString()
	{
		String str="";
		if(this.front==-1)
		{
			str="Queue is empty";
		}
		else
		{
			System.out.println("QUEUE ELEMENTS:");
			for(int i=this.front;i<=this.rear;i++)
			{
				str=str+this.arr[i]+"  ";
			}
		}
		return str;
	}
	public void insert(int value)
	{
		if(this.rear<this.arr.length-1)//4 -1<4 0 1 2 3 4<4
		{
			
			this.rear++;
			this.arr[this.rear]=value;
			if(this.front==-1)
			{
				this.front++;
			}
		}
		else
		{
			System.out.println("Queque is full");
		}
	}
	public Queue concat(Queue q2)
	{
		Queue new1=new Queue(this.arr.length+q2.arr.length);
		for(int i=q2.front;i<=q2.rear;i++)
		{
			new1.insert(q2.arr[i]);
		}
		for(int i=this.front;i<=this.rear;i++)
		{
			new1.insert(this.arr[i]);
		}
		
		
		
		return new1;
	}
	
	public int remove()
	{
		int value=0;
		if(front!=-1)
		{
			value=arr[front];

			if(front!=rear)
			{
				front++;
				
			}
			else
			{
				front=rear=-1;
			}
	
		}
		else
		{
			System.out.println("Queue is empty");
		}
		
		return value;
	}
	
}