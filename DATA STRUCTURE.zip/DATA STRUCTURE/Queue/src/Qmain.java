import java.util.Scanner;

public class Qmain {
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		
		System.out.println("Enter queue size");
		int size=sc.nextInt();
		Queue q1=new Queue(size);
		menu(q1);
		
		System.out.println("---------------------------------------");
		Queue q2=new Queue(size);
		menu(q2);

		Queue q3=q2.concat(q1);
		System.out.println(q3);
		
		
		
	}
	
	public static void menu(Queue q1)
	{
		int ch;
	do
	{
		System.out.println("1.InSERT");
		System.out.println("2.REMOVE");
		System.out.println("3.Display");
		System.out.println("0.exit");
		System.out.println("Enter your choice between 1-3");
		ch=sc.nextInt();
		
		switch(ch)
		{
		    case 1:
		    		System.out.println("enter data");
		    		int v=sc.nextInt();
		    		q1.insert(v);
		    		break;
		    		 
		    case 2:	q1.remove();
		    		break;
		    case 3:System.out.println(q1);
		    		break;
		    
		    default:System.out.println("Invalid choice");break;
		    
		   }
	}while(ch!=0);
	}
	
}
