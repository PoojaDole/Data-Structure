
public class Queue {

	private Employee arr[];
	private int rear;
	private int front;
	
	Queue(int size)
	{
		this.arr=new Employee[size];
		this.rear=-1;
		this.front=-1;
		
	}
	public String toString()
	{
		String str="";
		if(front==-1)
		{
			str="Queue is empty";
		}
		else
		{
			System.out.println("QUEUE");
			for(int i=this.front;i<=this.rear;i++)
			{
				str=str+this.arr[i]+"  ";
			}
		}
		str+="\n";
		return str;
	}
	public void insert(Employee value)
	{
		if(this.rear<this.arr.length-1)//4 -1<4 0 1 2 3 4<4
		{
			
			this.rear++;
			this.arr[rear]=value;
			if(this.front==-1)
			{
				this.front++;
			}
		}
		else
		{
			System.out.println("Queque is full");
		}
	}
	public void remove()
	{
	
		if(this.front!=-1)
		{
			System.out.println(this.arr[this.front]);

			if(this.front!=this.rear)
			{
				this.front++;
				
			}
			else
			{
				this.front=this.rear=-1;
			}
	
		}
		else
		{
			System.out.println("Queue is empty");
		}
		
		
	}
}