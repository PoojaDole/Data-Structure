
public class Main {

	public static void main(String[] args) {
		
		QueueLL qu=new QueueLL();
		
		qu.insert(10);
		qu.insert(80);
		qu.insert(50);
		qu.insert(100);
		System.out.println(qu);
		
		System.out.println("delete element:"+qu.remove());
		qu.insert(50);
		System.out.println("Top element:"+qu.peek());
		System.out.println(qu);
		
		
		
	}
	
}
