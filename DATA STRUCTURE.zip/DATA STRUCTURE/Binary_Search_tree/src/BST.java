
public class BST {
	
	Node root;
	BST()
	{
		this.root=null;
		
	}
	
	BST(Node root)
	{
		this.root=root;
	}
	
	public void insert(int data)
	{
		
		if(root==null)
		{
			Node newnode=new Node(data);
			root=newnode;
		}
		else
		{
			Node it=root;
			Node newnode=new Node(data);
			while(it!=null)
			{
				if(data<it.data)
				{
					if(it.left==null)
					{
						it.left=newnode;
						break;
					}
					else
						it=it.left;
				}
				else
				{
					if(it.right==null)
					{
						it.right=newnode;
						break;
					}
					else
						it=it.right;
				}
			}
		}
	}
	
	public void preprint()
	{
		System.out.print("PREORDER BST: ");
		preorder(root);
		System.out.println();
	}
	private void preorder(Node it) // plr
	{
		if(it!=null)
		{
			System.out.print(it.data +" ,");
			preorder(it.left);
			preorder(it.right);
		}
	}
	
	public void Inprint()
	{
		System.out.print("INORDER BST: ");
		inorder(root);
		System.out.println();
	}
	private void inorder(Node it) // lpr
	{
		if(it!=null)
		{
			inorder(it.left);
			System.out.print(it.data +" ,");
			inorder(it.right);
		}
	}
	
	public void Postprint()
	{
		System.out.print("INORDER BST: ");
		postorder(root);
		System.out.println();
	}
	public void delete(int data)
	{
		root=delete_by_value(root,data);
	}
	private Node delete_by_value(Node it,int data)
	{
		if(it==null)
		{
			return null;
		}
		else if(it.left==null && it.right==null)
		{
			return null;
		}
		else
		{
			
			if(data < it.data) // 3 < 3
			{
				it.left=delete_by_value(it.left, data); // 
				return it;
				
			}
			else if(data > it.data) // 3>3
			{
				it.right=delete_by_value(it.right,data);
				return it;
			}
			else
			{
				if(it.left==null)
				{
					Node tmp= it.right;
					it.right=null;
					return tmp;
				}
				else if(it.right==null)
				{
					Node tmp= it.left;
					it.left=null;
					return tmp;
				}
				else
				{
					
					int value =find_smallest(it.right);
					it.data=value;
					it.right=delete_by_value(it.right, value);
					
				}
			}
		}
		return it;
	}
	public void smallest_number()
	{
		Node it=root;
		if(it==null)
		{
			System.out.println(" Empty...");
		}
		else
		{
			while(it.left!=null)
			{
				it=it.left;
			}
			System.out.println("Smallest value: "+it.data);
		}
	}
	
	public void largest_number()
	{
		Node it=root;
		if(it==null)
		{
			System.out.println(" Empty...");
		}
		else
		{
			while(it.right!=null)
			{
				it=it.right;
			}
			System.out.println("Largest value: "+it.data);
		}
	}
	
	public void height_of_tree()
	{
		
	}
	public int find_smallest(Node it)
	{
		
		while(it.left!=null)
		{
			it=it.left;
		}
		
		return it.data;
	}
	private void postorder(Node it) // lrp
	{
		if(it!=null)
		{
			postorder(it.left);
			postorder(it.right);
			System.out.print(it.data +" ,");
		}
	}
  
	
	
}
