
public class Main {
	
	public static void main(String [] args)
	{
		BST tree=new BST();
		tree.insert(23);
		tree.insert(3);
		tree.insert(13);
		tree.insert(1);
		tree.insert(48);
		tree.insert(34);
		tree.insert(100);
		tree.insert(86);
		tree.insert(500);
		tree.smallest_number();
		tree.largest_number();
		
		//tree.preprint();
	    //tree.Postprint();
		//tree.delete(23);
		tree.Inprint();
		//tree.delete(100);
		tree.Inprint();
		
		
	}
}
