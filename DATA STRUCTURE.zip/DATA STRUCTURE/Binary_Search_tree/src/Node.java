
public class Node {

	Node left;
	Node right;
	int data;
	
	Node(int data)
	{
		this.left=null;
		this.right=null;
		this.data=data;
	}
	
	
	Node(int data,Node left,Node right)
	{
		this.left=left;
		this.right=right;
		this.data=data;
	}
	public String toString()
	{
		String str=" ";
		str=this.data+" ,";
		return str;
	}
	
}
