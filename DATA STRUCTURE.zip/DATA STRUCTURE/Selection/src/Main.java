
public class Main {

	public static void main(String[] args) {
		
		int [] arr= new int [] {10,0,78,505,11,158};
		Selection.sorted(arr);
		Selection.print(arr);
		System.out.println();
		int [] rr= new int [] {10,0,78,505,11,158};
		Selection.insert(rr);
		Selection.print(rr);
	}
}
