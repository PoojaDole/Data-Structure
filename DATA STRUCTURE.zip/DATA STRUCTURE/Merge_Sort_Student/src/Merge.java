
public class Merge {

	public void mergesort(Student s[],int l,int r)
	{
		if(l<r)
		{
			int mid=(l+r)/2;
			mergesort(s,l,mid-1);
			mergesort(s,mid+1,r);
			sort(s,l,r,mid);
		}
	}
	public void sort(Student s[],int left,int right,int mid)
	{
		int n1=mid-left+1;
		int n2=right -(mid+1)+1;
		
		Student arr[]=new Student[n1];
		Student[]brr=new Student [n2];
		
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=s[left+i];
		}
		
		for(int i=0;i<brr.length;i++)
		{
			brr[i]=s[mid+1+i];
		}
		
		int i=0,j=0,k=left;
		while(i<arr.length && j<brr.length)
		{
			if(arr[i].getAge()<=brr[j].getAge())
			{
				s[k]=arr[i];
				k++;
				i++;
			}
			else
			{
				s[k]=brr[j];
				k++;
				j++;
			}
		
		}
		if(i==arr.length)
		{
			while(j<brr.length)
			{
				s[k]=brr[j];
				k++;
				j++;
			}
		}
		else
		{
			while(i<arr.length)
			{
				s[k]=arr[i];
				k++;
				i++;
			}
			
		}
		
	}
	
	public  void display(Student [] arr)
	{
	  System.out.println("****************** S O R T E D ************************************");
	  for (int i = 0; i < arr.length; i++) {
		System.out.print("#"+arr[i]+"  \n");
	  }
	  System.out.println();
	}
}
