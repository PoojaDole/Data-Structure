
public class Student {

	private String name;
	private int age;
	private char g;
	Student(String name,int age,char g)
	{
		this.name=name;
		this.age=age;
		this.g=g;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public char getG() {
		return g;
	}
	public void setG(char g) {
		this.g = g;
	}
	
	public String toString() {
		return "Student [name= " + name + ", age=" + age + ", g=" + g + "]";
	}
	
}
