
public class Main {
	
	public static void main(String[] args) {
		
		Student []s=new Student [3];
		
		s[0]=new Student("Prabandh",25,'M');
		s[1]=new Student("Prjyot",26,'M');
		s[2]=new Student("Supriya",22,'f');
		Merge mg=new Merge();
		mg.mergesort(s,0,s.length-1);
		mg.display(s);
		
	}
}
