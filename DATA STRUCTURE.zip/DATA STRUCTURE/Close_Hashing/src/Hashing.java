
public class Hashing {

	Linklist str[];
	Hashing(int size)
	{
		str=new Linklist[size];
		for (int i = 0; i < str.length; i++) {
			str[i]=new Linklist();
		}
	}
	public void insert(String data)
	{
		int index=hashFunction(data);
		
		str[index].append(data);
		System.out.println(str[index]+ " is placed at position   ===>        "+ index);
	}
	public void remove(String data)
	{
		int index=search(data);
		int res=str[index].delete_by_value(data);
		if(res==1)
		{
			System.out.println(str[index]+" String is  found at     ===>       "+index);
		}
		else
		{
			System.out.println(str[index]+" String is not found at  ===>      "+ index);
			
		}
	}
	public int search(String data)
	{
		int index=hashFunction(data);
		boolean s= str[index].is_present(data);
			System.out.println(str[index]+" is removed from         ===>       "+ index);
		if(s==false)
		{	
			System.out.println(str[index]+" String is not found at  ===>       "+ index);
		}
		return index;
	}
	
	public int hashFunction(String data)
	{
		int sum=0;
		for (int i = 0; i < data.length(); i++) {
			
			sum+=data.charAt(i);
		}
		int index=sum% data.length();
		return index;
	}
	
	public String toString()
	{
		String sr=" ";
		for (int i = 0; i < str.length; i++) {
			
			sr+="Arr["+i+"] :"+str[i]+"\n ";
		}
		return sr;
	}
	
}
