
public class Main {

	public static void main(String[] args) {
		
		Hashing sh=new Hashing(7);
		sh.insert("Pooja");
		sh.insert("Monika");
		sh.insert("Sonali");
		sh.insert("qjbghgnza");
		sh.insert("aaaaa");
		System.out.println(sh);
		sh.remove("Pooja");
		System.out.println(sh);
		
	}
}
