
public class Node {
	
	    String data;
		Node next;

	    Node()
	    {
	        this.data=" ";
	        this.next=null;
	    }

	    Node(String data,Node next)
	    {
	        this.data=data;
	        this.next=next;    
	    }
	    Node(Node next)
	    {
	        this.data=" ";
	        this.next=next;  
	    }
	    Node(String data)
	    {
	        this.data=data;
	        this.next=null;  
	    }
	    
	}

	

