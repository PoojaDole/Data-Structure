
public class Main {

	public static void main(String[] args) {
		
		Group [] stu=new Group[6];
		System.out.println("\n************************* GROUP REQUEST ******************************\n");
		stu[0]=new Group(10,"Pratik Alhat    "," NON_IT");
		stu[1]=new Group(73,"Pooja Dole      "," NON_IT");
		stu[2]=new Group(75,"Prabandh Shinde "," NON_IT");
		stu[3]=new Group(000,"                 "," IT");
		stu[4]=new Group(000,"                 "," ANY");
		stu[5]=new Group(000,"                 "," ANY");
		for(int i=0;i<stu.length;i++)
		{		
			System.out.println(stu[i]);
		}
		System.out.println("\n :) HOPING FOR POSITIVE REPLY...!");
		
		
	}
}
