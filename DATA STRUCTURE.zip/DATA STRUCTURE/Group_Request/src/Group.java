
public class Group {
	static int c=1;
	int PRN;
	String name;
	String Background;
	
	Group(String background)
	{
		this.PRN=000;
		this.Background=background;
		this.name="";
		
		
	}
	Group(int prn,String name,String background)
	{
		
		this.PRN=prn;
		this.Background=background;
		this.name=name;
	}
	
	public String toString() {
		
		String str="["+ c++ +"] PRN:0"+this.PRN+"    NAME: "+this.name+"    Background: "+this.Background;
		
		return str;
	}
}
