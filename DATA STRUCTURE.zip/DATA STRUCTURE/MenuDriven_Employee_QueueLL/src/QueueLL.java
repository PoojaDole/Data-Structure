
public class QueueLL {

	Node front;
	Node rear;
	
	QueueLL()
	{
		this.front=null;
		this.rear=null;
			}
	
	QueueLL(Node front,Node rear)
	{
		this.front=front;
		this.rear=rear;
	}
	
	public void insert(Employee data)
	{
		Node newnode=new Node(data);
		
		if(front==null && rear==null)
		{
			front=newnode;
			newnode.next=null;
			 rear=front;
		}
		else
		{
		
			while(rear.next!=null)
			{
				rear=rear.next;
			}
			rear.next=newnode;
		}
	}
	public Employee remove() // to check queue is empty or not
	{
		Employee value=null;
		if(front==null)
		{
			System.out.println(" Queue is empty............!! ");
		}
		else if(front.next==null)
		{
			value=front.data;
			front=null;
			
		}
		else
		{
		//	System.out.println("value"+value);
			Node tmp=this.front;
			this.front=front.next;
			tmp.next=null;
			value=front.data;
			
		}
		return value;
	}
	public Employee peek()//it gives top element value
	{
		Node it=front;
		return it.data;
	}
	
	public  String toString()
	{
		String str="";
		if(rear==null && front ==null)
		{
			str="Queue is empty";
		}
		else
		{
			Node it=front;
			str+="Queue elements:===>";
			while(it!=null)
			{
				str+=it.data+",";
				it=it.next;
			}
			
		}
		return str;
	}
}
