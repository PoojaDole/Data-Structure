import java.util.Scanner;

public class Main {
	static 	Scanner sc=new Scanner(System.in);
		static QueueLL qu=new QueueLL();
	public static void main(String[] args) {
		
	
		
		menu_operation();
		
	}
	
	public static void menu_operation()
	{
		int ch;
	do
		{
		System.out.println("*******************************************************");
		System.out.println("1.Insert elment");
		System.out.println("2.Peek top element");
		System.out.println("3.Remove");
		System.out.println("4.Display");
		System.out.println("**************************************************");
		System.out.println("Enter ur choice");
		ch=sc.nextInt();
		switch(ch)
		{
		case 1:
		System.out.println("enter name:");
		sc.nextLine();
		String name=sc.nextLine();
		System.out.println("enter id");
		int id=sc.nextInt();
		System.out.println("enter salary");
		int  salary=sc.next().charAt(0);
		qu.insert(new Employee(id,salary,name));
		break;
		
		case 2:System.out.println(qu.peek());break;
		case 3:System.out.println(qu.remove());break;
		case 4:System.out.println(qu);break;
		default:
			System.out.println("invalid choice !!");
			
		}
	}while(ch!=0);
	}
}
