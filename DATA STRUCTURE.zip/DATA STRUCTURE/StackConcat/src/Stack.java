
public class Stack {
	 	int []arr;
	 	int top;
	
	 	Stack(int size)
	 	{
	 		this.arr=new int [size];
	 		this.top=-1;
	 	}
	public String toString()
	{
		String str="";
		if(top==-1)
		{
			str=("Stack is empty");
		}
		else
		{
			System.out.println("Stack element is: ");
			
			for(int i=top;i>=0;i--)
			{
				str=str+arr[i]+" ";
			}
		}
		return str;
	}
	public  void push(int data)
	{
		if(this.top<arr.length-1)
		{
			this.top++;
			arr[this.top]=data;
			
		}
		else
		{
			System.out.println("stack overflow");
		}
			
	}
	public  void pop()
	{
		if(top>-1)
		{
			System.out.println("Deleted element is "+ arr[top]);
			top--;
		}
		else
		{
			System.out.println("stack underflow");
		}
	}
	

	public  Stack concat(Stack s2)
	{int i;
		Stack con=new Stack(s2.arr.length+this.arr.length);
		for(i=0;i<=this.top;i++)
		{
			con.push(this.arr[i]);

		}
		for( i=0;i<=s2.top;i++)
		{
		
			con.push(s2.arr[i]);
		}
		return con;
	}
	
	public boolean equal(Stack s2)
	{
		if(this.arr.length!=s2.arr.length)
			return false;
		if(this.top!=s2.top)
		{
			return false;
		}
		for(int i=0;i<=this.top;i++)
		{
			if(this.arr[i]!=s2.arr[i])
			{
				return false;
			}
		}
		return true;
	}
}
