import java.util.Scanner;

public class Main {
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		
		
		System.out.println("Enter size");
		int size=sc.nextInt();
		Stack st1=new Stack(size);
		menu(st1);
 	
		System.out.println("Enter size");
		int s=sc.nextInt();
		Stack st2=new Stack(s);
		menu(st2);
	
		Stack s3=st1.concat(st2);
		System.out.println("--------------------------------");
		System.out.println(s3);
	
		if(st1.equals(st2))
		{
			System.out.println("s1 and s2 ae same");
		}
		else
		{
			System.out.println("s1 and s2 are diff");
		}
	}
 
	
 public static void menu(Stack st2)
 	{
	
	 int ch1;
	 do
	 {
	 	
	 	System.out.println("1.PUSH");
	 	System.out.println("2.POP");
	 	System.out.println("3.Display");
	 	System.out.println("0.exit");
	 	System.out.println("Enter your choice between 1-3");
	 	ch1=sc.nextInt();
	 	
	 	switch(ch1)
	 	{
	 	    case 1:
	 	    		System.out.println("Enter data");
	 	    		int data=sc.nextInt();
	 	    		 st2.push(data);
	 	    		 break;
	 	    		 
	 	    case 2:	st2.pop();
	 	    		break;
	 	    case 3:System.out.println(st2);
	 	    		break;
	 	    
	 	    default:System.out.println("Invalid choice");break;
	 	    
	 	   }
	 	}while(ch1!=0);
 }
}

