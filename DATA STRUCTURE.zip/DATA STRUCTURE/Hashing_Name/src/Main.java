
public class Main {

	public static void main(String[] args) {
		
		Hashing sh=new Hashing(5);
		sh.insertQ("Ganhhju");
		System.out.println(sh);
		sh.insertQ("Ganujhkj");
	sh.insertQ("vhgA Z");
	sh.insertQ(" tyuga");
	sh.insertQ("ram");

		System.out.println(sh);
	}
}
