
public class Hashing {
	static int c=0;
	String strarr[];
	Hashing()
	{
		strarr=new String[5];
	}
	
	Hashing(int size)
	{
		strarr=new String[size];
	}
	public void insert(String str)
	{
		int index=hashfunction(str);
		if(strarr[index]==null)
		{
			strarr[index]=str;
		}
		else
		{
				int flag=0;
				while(true)
				{
					if(index > strarr.length-1)
					{
						index++;
					}
					else
					{
						index=0;
					}
					if(strarr[index]==null)
					{
						strarr[index]=str;
						break;
					}
					
				}
//				index=(++index % strarr.length);
//				if(strarr[index]==null)
//				{
//					strarr[index]=str;
//					break;
//				}
			}
		System.out.println( str +" is placed at index: "+index);
		}
	
		
	
	public void insertQ(String str)
	{
		int index=hashfunction(str);
	 if(strarr[index]==null)
		{
			strarr[index]=str;
		}
		else
		{
				int i=1;
				while(true)
				{
					index += (i*i);
					if(index > strarr.length-1)
					{
						index=0;i=0;
					}
					if(strarr[index]==null)
					{	c++;
						strarr[index]=str;
						break;
					}
					i++;
					if(c==strarr.length)
					{
						System.out.println(" Array is full");
						break;
					}
					
				}
			}
		System.out.println( str +" is placed at index: "+index);
		}
	
		
	
	
	
	
	
	
	
	public void remove(String str)
	{
		
		int index=search(str);
		if(strarr[index]==null  )
		{
			System.out.println(" String is not available ");
		}
		else
		{
			strarr[index]=null;
			System.out.println( str +" is removed from index: "+index);
		}
			
	}
	public int search(String str)
	{
		int index=hashfunction(str);
		if(strarr[index]!=null && strarr[index].equals(str))
		{
			return index;
		}
		else
		{
			int flag=0;
			while(true)
			{
				if(index > strarr.length-1)
				{
					index++;
				}
				else if (index==strarr.length)
				{
					index=0;
					
				}
				if(strarr[index]!=null && strarr[index].equals(str))
				{
					return index;	
				
				}				
			}
		}
		
	}
	public void removeQ(String str)
	{
		int index = searchQ(str);
		strarr[index] = null;
		System.out.println(" and it is removed from " + index);
	}
	
	public int searchQ(String str)
	{
		int index=hashfunction(str);
		if(strarr[index]!=null && strarr[index].equals(str))
		{
			return index;
		}
		else
		{
			int i=1;
			while(true)
			{index+=(i*i);
				if(index > strarr.length-1)
				{
					index=0;i=0;
				}
				if(strarr[index]!=null && strarr[index].equals(str))
				{
					return index;	
				
				}	
				i++;
			}
		}
		
	}
	
	public String toString()
	{
		String str=" ";
		for(int i=0;i<strarr.length;i++)
		{
			str+=strarr[i]+" ";
		}
		return str;
	}
	public int  hashfunction(String str)
	{
		int sum=0;
		for (int i = 0; i < str.length(); i++) {
			sum+=str.charAt(i);
			
		}
		return (sum%str.length());
	}
	
}
