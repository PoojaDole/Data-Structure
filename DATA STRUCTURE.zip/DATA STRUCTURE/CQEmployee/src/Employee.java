
public class Employee {
	
	private int Id;
	private String Name;
	private int Salary;
	
	
	
	public Employee(int Id,int Salary,String name )
	{
		this.Id=Id;
		this.Name=name;
		this.Salary=Salary;
	}
	
	
	public int getId() {
		return Id;
	}


	public void setId(int id) {
		this.Id = id;
	}


	public String getName() {
		return Name;
	}


	public void setName(String name) {
		this.Name = name;
	}

	public void setSalary(int salary) {
		this.Salary =salary;
	}

	public int getSalary() {
		return this.Salary;
	}
	private int calculateSalary(int n)
	{
		return (this.Salary+n);
	}

	

	public String toString()
	{
		return new String("Employee ID : "+ this.Id+ " Employee Name: "+ this.Name+" Employee Basic  Salary: "+ (this.Salary )+" Rs");
	}
	public int getCalculateSalary(int n)
	{
		return calculateSalary(n);
	}
	

}
