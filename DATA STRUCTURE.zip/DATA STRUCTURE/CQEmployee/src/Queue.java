
public class Queue {
	
	private Employee []arr;
	private int front;
	private int rear;
	
	Queue()
	{
		this.arr=new Employee [5];
		this.front=-1;
		this.rear=-1;
	}
	Queue(int a)
	{
		this.arr=new Employee[a];
		this.front=-1;
		this.rear=-1;
	}
	public void insert(Employee data)
	{
		if(this.front==-1)
		{
			front++;
		}
		if(this.rear<this.arr.length-1&& front!=-1) 
		{
			if(this.rear<this.arr.length-1)
			{
				this.rear++; //-1
							}
			else
			{
				this.rear=0;
			}
		}
		else
		{
			System.out.println("full");
		}
		this.arr[rear]=data;

	}
	public Employee remove()
	{
		Employee value=null;
		if(this.front==-1||this.rear==-1)
		{
			System.out.println("empty");
		}
		if(this.front==this.rear)
		{
			this.front=-1;
			this.rear=-1;
		}
		if(this.front!=this.rear)
		{
			value=this.arr[this.front];
			
			if(this.front!=this.arr.length-1)
			{
				this.front++;
				
			}
			else
				this.front=0;
		}
		else
		{
			System.out.println("empty");
		}
		return value;
	}
	public String toString()
	{ 
		String str="Queue ele:";
		if(this.front==-1 || this.rear==-1)
		{
			System.out.println("Queue is empty");
		}
		else
		{
			for(int i=this.front;i!=this.rear;)
			{
				str=str+this.arr[i]+" ";
				
				if(i!=this.arr.length-1)
				{
					i++;
				}
				else
				{
					this.rear=0;
				}
			}
			str=str+this.arr[this.rear]+" ";
		}
		return str;
		
	}
	
}
