import java.util.Arrays;
import java.util.PriorityQueue;
import java.util.Queue;

public class Main {

	public static void main(String[] args) {
		
		int []arr=new int [] { 51 ,50,85,12,24};
	
		OuickSort qk=new OuickSort();
		qk.display(arr);
		qk.partition(arr, 0, arr.length-1);
		qk.display(arr);
		
		qk.display(arr);

	
	}
}
