
public class OuickSort {
	
	public  void partition(int arr[],int l,int h)
	{
		
	if(l<h)	            
	{
		
		int pi=sort(arr,l,h); //0   
		partition(arr,l,pi-1); //0 2
		partition(arr,pi+1,h);  //1 ,4    2,4
	}
		
	}
	public static int sort(int arr[],int l,int h) 
	{
		
		
		int p=h; //4   2
		int j=l;//2    0
		int i=l-1;//1  -1
		
		while(j!=p)
		{
			if(arr[j]<=arr[p])
			{
				i++;
				int temp=arr[j]; 
				arr[j]=arr[i];
				arr[i]=temp; 
			}
			j++;//1
		}
		i++;//0
		int temp=arr[j]; 
		arr[j]=arr[i];
		arr[i]=temp;
		
		return i;
	}
	public void display(int [] arr)
	{
	  System.out.println("****************** S O R T E D ************************************");
	  for (int i = 0; i < arr.length; i++) {
		System.out.print(arr[i]+"  ");
	  }
	  System.out.println();
	}
	
}
