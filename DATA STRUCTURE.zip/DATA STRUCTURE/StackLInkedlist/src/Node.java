
public class Node {

	int data;
	Node next;
	Node()
	{
		this.data=0;
		this.next=null;
	}
	Node(int data,Node top)
	{
		this.data=data;
		this.next=top;
	}
	
	Node(int data)
	{
		this.data=data;
		this.next=null;
	}
	Node(Node top)
	{
		this.data=0;
		this.next=top;
	}
	
	
}
