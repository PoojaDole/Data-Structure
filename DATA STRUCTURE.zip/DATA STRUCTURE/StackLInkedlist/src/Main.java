
public class Main {

	public static void main(String[] args) {
		
		Stackll stk=new Stackll();
		stk.push(10);
		stk.push(20);
		stk.push(240);
		System.out.println("peek"+stk.peek());
		System.out.println(stk);
		stk.pop();
		System.out.println("peek"+stk.peek());
		System.out.println(stk);
	}
}
