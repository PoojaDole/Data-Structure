
public class Node {

	Node next;
	Node pre;
	int data;
	public Node()
	{
		this.data=0;
		this.pre=null;
		this.next=null;
	}
	public Node(Node pre,Node next,int data)
	{
		this.data=data;
		this.pre=pre;
		this.next=next;
	}
	
	public Node(Node pre,Node next)
	{
		this.data=0;
		this.pre=pre;
		this.next=next;
	}
	public Node(int data)
	{
		this.data=data;
		this.pre=null;
		this.next=null;
	}
	
	public String toString()
	{
		String str=" ";
		str=this.data+" ";
		return str;
	}
	
	
}
