
public class DoublyLL {

	Node head;
	Node tail;
	
	DoublyLL()
	{
		this.head=null;
		this.tail=null;
	}

	public void insert(int data)
	{
		Node newnode = new Node(data);
		if(head==null)
		{
			head=newnode;
			tail=newnode;
		}
		else 
		{
			
			newnode.next=head;
			head.pre=newnode;
			head=newnode;
		}
		
	}
	
	public void append(int data)
	{
		Node newnode=new Node(data);
		if(head==null)
		{
			head=newnode;
		}
		else
		{
			tail.next=newnode;
			newnode.pre=tail;
			tail=newnode;
		}
	}
	
	
	public int getNodeCount()
    {
    	int count=0;
    	Node it=head;
    	while(it!=null)
    	{
    		count++;
    		it=it.next;
    	}
    	return count;
    }
	
	public void  insert_by_position(int pos,int data)
	{
		Node newnode=new Node(data);
		if(pos==1)
		{
			insert(data);
		}
		else if(pos==getNodeCount()+1)
		{
			append(data);
		}
		else if(pos>1 && pos< getNodeCount()+1)
		{
			Node it=head;
			for(int i=1;i<pos-1;i++)
			{
				it=it.next;
			}	
			/*Node tmp=it.next;
			it.next=newnode;
			newnode.pre=it;
			newnode.next=tmp;
			tmp.pre=newnode;
			*/
			newnode.next=it.next;
			newnode.pre=it;
			newnode.next.pre=newnode;
			it.next=newnode;
			
		}
	}
	public void delete_first()
	{
		if(head==null)
		{
			System.out.println("Queue is empty....!!");
		}
		else 
		{
			Node it=head;
			if(head.next==null)
			{
				head=tail=null;
			}
			else
			{
				head=it.next;
				head.pre=null;
				it.next=null;
			}
			
		}
	}
	public void delete_last()
	{
		if(head==null)
		{
			System.out.println(" Doubly Queue...empty");
		}
		else
		{
			if(head.next==null)
			{
				head=tail=null;
			}
			else
			{
				Node it=tail;
				tail.pre.next=null;
				tail=tail.pre;
				it.pre=null;
				
			}
		}
	}
	public void delete_by_position(int pos)
	{
		Node it=head;
		if(pos==1)
		{
			delete_first();
		}
		else
		{
			if(pos==getNodeCount())
			{
				delete_last();
			}
			else
			{
				for(int i=1;i<pos-1;i++)
				{
					it=it.next;
				}
				Node t=it.next;
				it.next=it.next.next;
				t.pre=null;
				t.next=null;
			}
		}
	}
	public void print_reverse()
	{
		System.out.println("********Reverse Print*************");
		if(head==null)
		{
			System.out.println(" Queue is null");
		}
		else
		{
			while(tail!=null)
			{
				System.out.print(tail.data);
				tail=tail.pre;
			}
		}
	}
	public void print_forward()
	{
		System.out.print("\nForward Print===>>>");
		Node it=head;
		if(head==null)
		{
			System.out.println(" Doubly Queue is empty");
		}
		else
		{
			while(it!=null)
			{
				System.out.print(it.data+" ");
				it=it.next;
			}
		}
	}
	public void even_no()
	{
		System.out.print("\neven no:==========>>");
		if(head==null)
		{
			System.out.println("Doubly Queue is empty");
		}
		else
		{
			Node it=head;
			while(it!=null)
			{
				if(it.data%2==0)
				{
					System.out.print(it);
				}
				it=it.next;
			}
		}
	}
	public void odd_no()
	{
		System.out.print("\nodd no=========>>>");
		if(head==null)
		{
			System.out.println("Doubly Queue is empty");
		}
		else
		{
			Node it=head;
			while(it!=null)
			{
				if(it.data%2!=0)
				{
					System.out.print(it);
				}
				it=it.next;
			}
		}
	}
	public String toString()
	{
		String str=" \nelements====>>";
				if(head==null && tail==null)
				{
					str=" Doubly Queue is empty";
				}
				else
				{
					Node it=head;
					while(it!=null)
					{
						str+=it+" ,";
						it=it.next;
					}
					
				}
			return str;
	}
	
}
