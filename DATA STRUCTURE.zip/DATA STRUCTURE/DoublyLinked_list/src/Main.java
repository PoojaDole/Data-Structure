
public class Main {

		public static void main(String[] args) {
			
			DoublyLL dq=new DoublyLL();
			dq.insert(10);
			dq.append(30);
			System.out.println(dq);
			dq.insert_by_position(2, 60);
			dq.insert(40);
			dq.append(1003);
			dq.print_forward();
			dq.delete_by_position(2);
			dq.even_no();
				dq.odd_no();
				System.out.println(dq);	
			
		}
}
