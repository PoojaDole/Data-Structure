package SingleDirecetedGraph;

public class Graph {

	int vertex;
	boolean arrGraph[][];

	Graph(int vertex)
	{
		this.vertex=vertex;
		this.arrGraph=new boolean [ vertex][ vertex];
	}
	
	 public void addPath(int i,int j)
	 {
		 arrGraph[i][j]=true;
		
	 }
	 public void removePath(int i,int j)
	 {
		 arrGraph[i][j]=false;
		 
	 }
	 public String toString()
	 {
		 StringBuffer s= new StringBuffer();
		 for (int i = 0; i < arrGraph.length; i++) {
			s.append(i+"  :  ");
			for(boolean tmp : arrGraph[i])
			{
				s.append((tmp ? 1 : 0) +"  ");
			}
			s.append("\n");
		}
		 return s.toString();
	 }
	
}
