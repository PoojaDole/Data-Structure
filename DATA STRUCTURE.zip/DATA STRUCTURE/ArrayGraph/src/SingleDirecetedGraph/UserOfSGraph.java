package SingleDirecetedGraph;

import javax.sound.midi.Synthesizer;

public class UserOfSGraph {

	public static void main(String[] args) {
		
		Graph g=new Graph(5);
		g.addPath(1, 1);
		g.addPath(4, 2);
		g.addPath(2, 3);
		g.addPath(1, 2);
		g.addPath(0, 1);
		g.addPath(0, 2);
		System.out.println(g);
	}
}
