
public class UserOfGraph {

	public static void main(String[] args) {
		
		DoubleDiretedGraph g1=new DoubleDiretedGraph(5);
		
		g1.addPath(1,2);
		g1.addPath(3,0);
		g1.addPath(2, 3);
		System.out.println(g1);
	}

	
}
