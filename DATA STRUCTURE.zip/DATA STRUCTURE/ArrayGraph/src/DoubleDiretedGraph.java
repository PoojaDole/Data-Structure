
public class DoubleDiretedGraph {

	int numberOfVertex;
	boolean arr[][];
	
	DoubleDiretedGraph(int numberOfVertex)
	 {
		 this.numberOfVertex=numberOfVertex;
		 this.arr=new boolean[numberOfVertex][numberOfVertex];
	 }
	 
	 public void addPath(int i,int j)
	 {
		 arr[i][j]=true;
		 arr[j][i]=true;
	 }
	 public void removePath(int i,int j)
	 {
		 arr[i][j]=false;
		 arr[j][i]=false;
	 }
	 public String toString()
	 {
		 StringBuilder s=new StringBuilder();
		 for (int i = 0; i < arr.length; i++) {
			s.append( i +" : ");
			for(boolean j : arr[i] )
				s.append((j ? 1 : 0)+" ");
			s.append("\n");
		}
		 return s.toString();
				 
	 }
	
	
}
