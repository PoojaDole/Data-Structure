package StringGraphVertex;

public class UserOfStringGraph {

	public static void main(String[] args) {
		
		StringSgraph obj=new StringSgraph(5);
		obj.addPath("AA", "BB");
		System.out.println(obj);
	}
}
