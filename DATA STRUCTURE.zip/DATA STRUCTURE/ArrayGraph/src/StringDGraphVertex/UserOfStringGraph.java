package StringDGraphVertex;

public class UserOfStringGraph {

	public static void main(String[] args) {
		
		StringDgraph obj=new StringDgraph(5);
		obj.addPath("AA", "BB");
		obj.RemovePath("AA", "BB");
		System.out.println(obj);
	}
}
