package StringDGraphVertex;

public class StringDgraph {

	int noOfVertex;
	String strarr[];
	boolean arrpath [][];
	
	StringDgraph(int noOfVertex)
	{
		this.noOfVertex=noOfVertex;
		this.strarr=new String[]{"AA","BB","CC","DD","DD"};
		this.arrpath=new boolean [noOfVertex][noOfVertex];	
	}
	void addPath(int i,int j)
	{
		arrpath[i][j]=true;
		arrpath[j][i]=true;
	}
	
	void addPath(String ii,String jj)
	{
		int i=getIndex(ii);
		int j=getIndex(jj);
		if(i>=0 && j>=0)
		{
			arrpath[i][j]=true;
			arrpath[j][i]=true;
		}
		else
		{
			System.out.println("String is not found in  string array ");
		}
		
	}
	void RemovePath(String ii,String jj)
	{
		int i=getIndex(ii);
		int j=getIndex(jj);
		if(i>=0 && j>=0)
		{
			arrpath[i][j]=false;
			arrpath[j][i]=false;
		}
		else
		{
			System.out.println("String is not found in  string array ");
		}
		
	}
	private int getIndex(String str)
	{
		for (int i = 0; i < strarr.length; i++) {
			if(strarr[i].equals(str))
			{
				return i;
			}
		}
		return -1;
	}
	public String toString()
	{
		StringBuffer b=new StringBuffer();
		for (int i = 0; i < arrpath.length; i++) {
			b.append(strarr[i]+" : ");
			for(boolean tmp : arrpath[i])
			{
				b.append((tmp? 1:0 )+" ");
			}
			b.append("\n");
		}
		
		return b.toString();
	}
}
