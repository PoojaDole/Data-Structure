

public class Main {

	public static void main(String[] args) {
		
		
		Linklist l=new Linklist();
		l.insert(110);
		l.append(20);
		l.Insert_By_Position(2, 104);
		l.append(50);
		l.append(5);
		l.Insert_By_Position(2, 200);
		l.Delete_By_Position(2);
		l.append(507);
		System.out.println(l);
	//	l.Reverse_likedlist();
		System.out.println(l);
		l.print_forward();
		l.print_reverse();
		l.odd_elements();
		l.even_elements();
		l.Smallest_Elements();
		l.Biggest_Element();
	}

	
}
