
public class Box {
	private String b_color;
	private int b_height;
	private int b_width;
	private int b_weight;
	
	
	public Box(String b_color,int b_height,int b_width,int b_weight) {
		this.b_color=b_color;
		this.b_height=b_height;
		this.b_weight=b_weight;
		this.b_width=b_width;
	}


	@Override
	public String toString() {
		return "Box b_color : " + b_color + "  b_height :  " + b_height + " b_width : " + b_width + "  b_weight : " + b_weight+"\n";
	}


	public String getB_color() {
		return b_color;
	}


	public void setB_color(String b_color) {
		this.b_color = b_color;
	}


	public int getB_height() {
		return b_height;
	}


	public void setB_height(int b_height) {
		this.b_height = b_height;
	}


	public int getB_width() {
		return b_width;
	}


	public void setB_width(int b_width) {
		this.b_width = b_width;
	}


	public int getB_weight() {
		return b_weight;
	}


	public void setB_weight(int b_weight) {
		this.b_weight = b_weight;
	}
	

}
