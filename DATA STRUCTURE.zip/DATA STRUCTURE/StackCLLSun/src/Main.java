
public class Main {

	public static void main(String[] args) {
		
		Box [] s=new Box [5];
		s[0]=new Box("Red",5,2,3);
		s[1]=new Box("Green",5,6,1);
		s[2]=new Box("Black",8,9,6);
		s[3]=new Box("yellow",8,4,1);
		s[4]=new Box("Orange",12,20,4);
		CircularLL cll=new CircularLL();
		cll.push(s[0]);
		cll.push(s[1]);
		cll.push(s[2]);
		cll.push(s[3]);
		cll.push(s[4]);
		cll.pop();

		System.out.println(cll);
		
	}
}
