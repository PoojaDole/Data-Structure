
public class Node {
	Box data;
	Node next;
	
	Node()
	{
		this.data=null;
		this.next=null;
	}

	Node(Box data)
	{
		this.data=data;
		this.next=null;
	}
	Node(Node next)
	{
		this.data=null;
		this.next=next;
	}
	Node(Box data,Node next)
	{
		this.data=data;
		this.next=next;
	}
	public String toString()
	{
		String str="";
		str=this.data+" ";
		return str;
	}
}
