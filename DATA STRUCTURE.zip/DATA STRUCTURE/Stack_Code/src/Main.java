import java.util.LinkedList;
import java.util.Queue;

public class Main {

	public static void main(String[] args) {
		
		Stack s1=new Stack();
		s1.push(10);
		s1.push(100);
		s1.push(1000);
		s1.push(25);
		s1.push(257);
		s1.push(252);
		s1.pop();
		s1.peek();
//		Queue<Integer>a=new LinkedList<Integer>();
		
		System.out.println(s1);
	}
}
