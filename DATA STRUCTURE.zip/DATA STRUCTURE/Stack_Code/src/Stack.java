
public class Stack {
	int arr[];
	int top;
	
	Stack()
	{
		this.arr=new int [5];
		this.top=-1;
	}
	Stack(int size)
	{
		this.arr=new int [size];
		this.top=-1;
	}
	public void push(int data)
	{
		if(top<arr.length-1)
		{
			top++;
			arr[top]=data;
		}
		else
		{
			System.out.println("Overflow..");
		}
			
	}
	public void pop()
	{
		if(top==-1)
		{
			System.out.println("empty");
		}
		else
		{
			
			System.out.println("Deleted element: " +arr[top]);
			top--;	
		}
	}
	public void peek()
	{
		String str="";
		int value=-55;
		if(top==-1)
		{
			System.out.println(" empty");
		}
		else
		{
			//str=str+" Peek is highest element "+arr[top];
			
			System.out.println("Peek is highest element "+arr[top]);
		}
		//return str;
	}
	
	public String toString()
	{
		String str="";
		for(int i=top;i>=0;i--)
		{
			str+=(arr[i]+" ");
		}
		return str;
	}
}
