
public class DQueue {
	
	int arr[];
	private int front;
	private int rear;
	public DQueue(int size)
	{
		arr=new int[size];
		this.front=-1;
		this.rear=-1;
	}
	
	public DQueue(int front,int rear,int size)
	{
		arr=new int[size];
		this.front=front;
		this.rear=rear;
	}
	
	public void insertRear(int value)
	{
		if(front==0 && rear==arr.length-1)// if all elements present in queue no empty block
		{
			System.out.println("Queue is full....!!");
		}
		if(front==-1 && rear==-1) // if empty queue then insert first element 
		{
			front=rear=0;// increase by 1 or both placed at first position
			arr[rear]=value;
		}
		else
		{
			if(rear!=arr.length)
			{
				rear++;  // 
				arr[rear]=value;
			}
			else
			{
				 // if before front is empty space then
				front--;
				for(int i=this.front;i<this.rear;i++)
				{
					arr[i]=arr[i+1];
				}
				arr[this.rear]=value;
				
			}
				
		}
	}
	
	
	public void insertFront(int value)
	{
		if(this.front==0 && this.rear==this.arr.length-1)// if all elements present in queue no empty block
		{
			System.out.println("Queue is full....!!");
		}
		if(this.front==-1 && this.rear==-1) // if empty queue then insert first element 
		{
			this.front=this.rear=0;// increase by 1 or both placed at first position
			arr[this.front]=value;
		}
		else
		{
			if(this.front!=0)
			{
				this.front--;  //  // if before front is empty space then
				arr[this.front]=value;
			}
			else
			{
				 
				rear++; // if front is not at 0 nd rear is not at last then shift elements to right side / means rear side
				for(int i=this.rear;i>this.front;i--)
				{
					arr[i]=arr[i-1];
				}
				arr[this.front]=value;
				
			}
				
		}
	}
	public int deleteRear()
	{
		int value=-99;
		if(this.front==-1 && this.rear==-1)
		{
			System.out.println("empty queue...!!");
		}
		else
		{
			if(this.rear==this.front)
			{
				this.rear=this.front=-1;
			}
			else
			{
				this.rear--;
				value=arr[this.rear];
			}
		}
		return value;
		
	}
	
	
	public int deleteFront()
	{
		int value=-99;
		if(this.front==-1 && this.rear==-1)
		{
			System.out.println("empty queue...!!");
		}
		else
		{
			if(this.rear==this.front)
			{
				this.rear=this.front=-1;
			}
			else
			{
					
				value=arr[this.front];
				this.front++;
			}
		}
		return value;
		
	}
	public String toString()
	{
		String str ="";
		
		if(this.front==-1 || this.rear==-1)
		{
			str=" Queue is empty"; 
		}
		else
		{
			for(int i=this.front;i!=this.rear;)
			{
				str+=arr[i]+" ";
				if(i!=this.arr.length-1)
				{
					i++;
				}
				else
				{
					this.rear=0;
				}
			}
			str+=arr[this.rear];
		}
		return str;
		
	}
	
	
	
}
