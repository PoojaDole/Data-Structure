import java.util.Scanner;

public class DQMain {
	
	static Scanner sc=new Scanner(System.in);
	static DQueue dq;
	public static void main(String[] args) {
		
		System.out.println("enter length of array");
		
		int len=sc.nextInt();
		dq=new DQueue(len);
		
		menu_Operation();
	}
	public static void menu_Operation() {
		
		int ch;
		do
		{
			
		System.out.println("*******************************************************");
		System.out.println("0.Exit..");
		System.out.println("1.Insert Rear");
		System.out.println("2.Insert front");
		System.out.println("3.Delete from rear");
		System.out.println("4.Delete from front");
		System.out.println("5.Display");
		System.out.println("_______________________________________________________________");
		System.out.println("enter ur choice...........");
		ch=sc.nextInt();
		System.out.println("*******************************************************");
		switch(ch)
		{
		
		case 1:dq.insertRear(10);break;
		case 2:dq.insertFront(20);break;
		case 3:dq.deleteRear();break;
		case 4:dq.deleteFront();break;
		case 5:System.out.println(dq);break;
		default: System.out.println("exit.........");
		
		}
		
		}while(ch!=0);
		
	
	}
}
