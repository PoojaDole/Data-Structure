
public class Objectstream {

	public static void main(String[] args) {
		System.out.println("hii");
	}
}
