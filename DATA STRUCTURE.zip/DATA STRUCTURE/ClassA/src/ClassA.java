//import java.io.DataInputStream;
//import java.io.DataOutputStream;
//import java.io.FileInputStream;
//
//public class ClassA {
//
//	public class fileOperations {
//
//	}
//
//	void fileOperations() throws Exception
//	{
//		DataOutputStream dos=new DataOutputStream("fiellovation")
//				System.out.println("connection created");
//	dos.writeInt(1000);
//	dos.writeChar('A');
//	dos.writeBoolean(true);
//	dos.writeInt(2000);
//	System.out.println("data witten");
//	dos.close();
//	System.out.println("------------------");
//	
//	
//		DataInputStream dis=new DataInputStream(new FileInputStream("file location"));
//		System.out.println("connection created");
//		System.out.println(dis.readInt());
//		System.out.println(dis.readChar());
//		System.out.println(dis.readBoolean());
//		System.out.println(dis.readInt());
//	
//	System.out.println("data retrived");
//	dis.close();
//	}
//	
//	public static void main(String[] args) throws Exception{
//		
//		new ClassA.fileOperations();
//	}
//}
