
public class Node {

	Student data;
	Node next;
	Node()
	{
		this.data=null;
		this.next=null;
	}
	Node(Student data,Node top)
	{
		this.data=data;
		this.next=top;
	}
	
	Node(Student data)
	{
		this.data=data;
		this.next=null;
	}
	Node(Node top)
	{
		this.data=null;
		this.next=top;
	}
	
	
}
