
public class Stackll {

	Node top=null;
	
	public void push(Student data)
	{
		Node newnode=new Node(data);  // new node 10 null 
		if(top==null)
		{
			newnode.next=top;
			top=newnode; /// here we add first node 10 null
		}
		else
		{
			Node it=top;
			newnode.next=top;
			top=newnode;
		}
		
	}
	public Student  pop() //delete first element
	{
		Student value=null;
		if(top==null)
		{
			System.out.println("stack is empty");
		}
		else
		{
			Node it=top; // delete top element
		 value =it.data;
			top=top.next;	
		}
		return value;
	}
	public Student peek()
	{
		Student value=null;
		if(top==null)
		{
			System.out.println("stack is empty");
		}
		else
		{
			value=top.data;// top value 
			return top.data;
		}
		return value;
	}
	public String toString()
	{
		String str="";
		if(top==null)
		{
			str="stack is empty";
				
		}
		else
		{
			Node it=top;
			while(it!=null)
			{
				str+=it.data+" ,";
				it=it.next;
			}
		}
		return str;
	}
	
}
