import java.util.Scanner;

public class Main {

	static Scanner sc=new Scanner(System.in);
	static Stackll stk=new Stackll();
	public static void main(String[] args) {
		menu_operation();
		sc.close();
	}
	public static void menu_operation()
	{
		int ch;
	do {
			
		System.out.println("1.push the data");
		System.out.println("2.peek the data");
		System.out.println("3.pop the data");
		System.out.println("4.Display stack element");
		System.out.println("0.exit");
		System.out.println("enter a choice");
		ch=sc.nextInt();
		
		switch(ch)
		{
		
			case 1:System.out.println("enter name:");
			sc.nextLine();
			String name=sc.nextLine();
			System.out.println("enter age");
			int age=sc.nextInt();
			System.out.println("enter gender");
			char g=sc.next().charAt(0);
			stk.push(new Student(name,age,g));
			break;
			
			case 2:
			
				System.out.println("peek====> "+stk.peek());
				break;
				
			case 3:stk.pop();break;
			case 4:System.out.println(stk);break;
			default: System.out.println("invalid choice so exit....!!");break;
		
		}
	
	}while(ch!=0);
	}
}
