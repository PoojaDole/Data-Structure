
public class Hashing {

	String str [];
	
	Hashing()
	{
		str=new String[5];
	}
	
	Hashing(int size)
	{
		str=new String[size];
	}
	
	public void insert(String st)
	{
		int index=hashfunction(st);
		
		if(str[index]==null )
		{
			str[index]=st;
		}
		else
		{
			int flag=0;
			while(true)
			{
				if(index < str.length-1)
				{
					index++;
				}
				else
				{
					index=0;
					++flag;
					if(flag==2)
					{
						break;
					}
				}
				if(str[index]==null)
				{
					str[index]=st;
					break;
				}
				
			}
		}
		System.out.println(st+" is placed at index "+index);
	}
	public void remove(String st)
	{
		int index=search(st);
		System.out.println(index+" index");
		if(str[index]==null)
			System.out.println(" empty place ");
		else
		{
			str[index]=null;
			System.out.println(st+" is removed from location"+index);
			
		}
		
	}
	public int search(String st)
	{
		int index=hashfunction(st);
		if(str[index]!=null && str[index].equals(st))
		{
			return index;
			
		}
		else
		{int flag=0;
			while(true)
			{
				
				if(index < str.length-1)
				{
					index++;
				}
				else
				{
					index=0;
					++flag;
					if(flag==2)
					{
						System.out.println("Invalid position");
						break;
					}
					
				}
				if(str[index]!=null && str[index].equals(st))
				{
					return index;
				}
			}
			
		}
		return index;
	}
	
	public void insertQ(String st)
	{
		int index=hashfunction(st);
		if(str[index]==null)
		{
			str[index]=st;
		}
		else
		{
			int i=1;
			while(true)
			{
				index=(index+(i*i));
				if(index > str.length-1)
				{
				 index=0;i=0;
					
				}
				if(str[index]==null)
				{
					str[index]=st;
					break;
				}
				i++;
			}
		}
		System.out.println(st+" is placed at index "+index);
		
	}
	public void removeQ(String st)
	{
		int index=searchQ(st);
		if(str[index]==null ||  str[index].equals(st))
			System.out.println(" String is not present in array");
		else
		{
			str[index]=null;
			System.out.println(st +" is removed from location "+index +" by Quadratic search");
		}

		
	}
	public int searchQ(String st)
	{
		int index=hashfunction(st);
		if(str[index]!=null && str[index].equals(st))
		{
			return index;
		}
		else
		{
			int i=1;
			while(true)
			{
				index=(index+(i*i));
				if(index > str.length-1)
				{
					index=0;i=0;
		//			System.out.println("Index: "+index);		
				}
				if(str[index]!=null && str[index].equals(st))
				{
					return index;
				}
				i++;
			}
		}
	}
	
	public String toString()
	{
		String s="***** Hashing ele: *****\n";
		for (int i = 0; i < str.length; i++) {
			
			s+=str[i]+" ,";
		}
		return s;
	}
	public int hashfunction(String st)
	{
		int sum=0;
		for(int i=0;i<st.length();i++)
		{
			sum+=st.charAt(i);
		}
		
		return (sum% (st.length()));
		
	}
	
}
