
public class Main {

	public static void main(String[] args) {
		
		Hashing h=new Hashing(10);
//		h.insert("Pooja");
//		h.insert("Ganu");
//		
//		System.out.println(h);
//		//h.remove("pooja");
//		h.remove("Pooja");
//		h.remove("Ganu");
//		System.out.println(h);
		
		h.insert("Pooja");
		h.insert("");
		
//		h.insertQ("Pooja");
//		System.out.println(h);
//		h.insertQ("Ram");
//		h.insertQ("Sanu");
//		System.out.println(h);
//		h.insert("RAju");
		System.out.println(h);
	}
}
