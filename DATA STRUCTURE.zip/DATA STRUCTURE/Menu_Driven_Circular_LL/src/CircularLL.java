
public class CircularLL {

	Node head;
	CircularLL()
	{
		this.head=null;
	}
	CircularLL(Node head)
	{
		this.head=head;
	}
	
	public void append(Student data)
	{
		Node newnode=new Node(data);
		if(head==null)
		{
			this.head=newnode;
			head.next=newnode;
		}
		else
		{
			if(head.next==head)
			{
				
				newnode.next=head;
				head.next=newnode;
				
			}
			else
			{
				Node it=head;
				while(it.next!=head)
				{
					it=it.next;
				}
				it.next=newnode;
				newnode.next=head;
			}
		}
	}
	public int getCouunt()
	{
		int c;
		if(head==null)
		{
			c=0;
			return c;
		}
		else
		{
			 c=1;
			Node it=head;
			while(it.next!=head)
			{
				c++;
				it=it.next;
			}
		}
		return c;
	}
	public void delete_first()
	{
		if(head==null)
		{
			System.out.println(" CLL is empty");
		}
		else
		{
			if(head.next==head)
			{
				head.next=null;
				head=null;
			}
			else
			{
				Node it=head;
				while(it.next!=head)
				{
					it=it.next;
				}
				it.next=head.next;
				Node t=head;
				head=head.next;
				t.next=null;
				
			}
		}
	}
	public void delete_last()
	{
		if(head==null)
		{
			System.out.println("Cll is empty");
		}
		else
		{
			if(head.next==head)
			{
				head.next=null;
				head=null;
			}
			else
			{
				Node it=head;
				while(it.next.next!=head)
				{
					it=it.next;
				}
				it.next.next=null;
				it.next=head;
			}
		}
	}
	public void delete_by_position(int pos)
	{
		
		if(pos==1)
		{
			delete_first();
		}
		else if(pos==getCouunt())
		{
			delete_last();
		}
		else if(pos>1 && pos<getCouunt())
		{
			Node it=head;
			for(int i=1;i<pos-1;i++)
			{
				it=it.next;
			}
			Node t=it.next;
			t=null;
			it.next=it.next.next;
		
		}
		else
		{
			System.out.println("Invalid position...");
		}	
	}
	public void insert_by_position(Student data,int pos)
	{
		Node newnode=new Node(data);
		if(pos==1)
		{
			insert(data);
		}
		else if(pos==getCouunt()+1)
		{
			append(data);
		}
		else if(pos>1 && pos<(getCouunt()))
		{
			Node it=head;
			for(int i=1;i<pos-1;i++)
			{
				it=it.next;
			}
			newnode.next=it.next;
			it.next=newnode;
			
		}
		else
		{
			System.out.println(" Invalid position");
		}
	}
	public void insert(Student data)
	{
		Node newnode=new Node(data);
		if(head==null)
		{
			this.head=newnode;
			head.next=newnode;
		}
		else
		{
			if(head.next==head)
			{
				newnode.next=head;
				head.next=newnode;
				head=newnode;
			}
			else
			{
				Node it=head;
				newnode.next=head;
				
				while(it.next!=head)
				{
					it=it.next;
				}
				it.next=newnode;
				head=newnode;
			}
		}
	}
	public String toString()
	{
		String str=" ";
		Node it=head;
		if(it==null)
		{
			str=" List is empty";
		}
		else
		{
			
			while(it.next!=head)
			{
				str+=it.data+" ,";
				it=it.next;
			}
			str+=it.data;
		}
		return str;
	}
}
