import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Student s;
		
		
		CircularLL cll=new CircularLL();
		
		int ch,age;
		String name=""; char g;
		int pos;
		
		Scanner sc=new Scanner(System.in);
		do
		{
		System.out.println("*********************************************");
		System.out.println("1.Insert");
		System.out.println("2.Append");
		System.out.println("3. Insert by position");
		System.out.println("4.Delete first");
		System.out.println("5.Delete last");
		System.out.println("6.Delete by position");
		System.out.println("7.Display");
		System.out.println("*********************************************");
		System.out.println("Enter ur choice");
		ch=sc.nextInt();
		switch(ch)
		{
		case 1: System.out.println(" Enter Name");
				sc.nextLine();
				name=sc.nextLine();
				System.out.println("Enter age: ");
				age=sc.nextInt();
				System.out.println("Enter gender");
				g=sc.next().charAt(0);
				s=new Student(name,age,g);
				cll.insert(s);
				break;
		case 2:
			System.out.println(" Enter Name");
			sc.nextLine();
			name=sc.nextLine();
			System.out.println("Enter age: ");
			age=sc.nextInt();
			System.out.println("Enter gender");
			g=sc.next().charAt(0);
			s=new Student(name,age,g);
			cll.append(s);	
			break;
			
		case 3:
			System.out.println(" Enter Name");
			sc.nextLine();
			name=sc.nextLine();
			System.out.println("Enter age: ");
			age=sc.nextInt();
			System.out.println("Enter gender");
			g=sc.next().charAt(0);
			s=new Student(name,age,g);
			System.out.println("Enter position");
			pos=sc.nextInt();
			cll.insert_by_position(s, pos);
			break;
		case 4:
				cll.delete_first();break;
			
		case 5:
				cll.delete_last();break;
		
		case 6:
				System.out.println("Enter position");
				pos=sc.nextInt();
				cll.delete_by_position(pos);break;
		case 7:
				System.out.println(cll);break;
			
			
		}
		}while(ch!=0);
			
	}
}
