
public class Main {

	public static void main(String[] args) {
		
		Student [] s=new Student [4];
		s[0]=new Student("Pooja Dole",21,'f');
		s[1]=new Student("Ganu Dole",20,'M');
		s[2]=new Student("Gauri Khot",30,'f');
		s[3]=new Student("Supriya Kharamate",29,'f');
		CircularLL cll=new CircularLL();
		cll.insert(s[0]);
		cll.append(s[2]);
		cll.insert(s[3]);
		cll.append(s[1]);
//		System.out.println("*********************************************");
//		System.out.println(cll);
		cll.insert_by_position(s[1], 2);
//		cll.insert_by_position(s[3], 4);
//		System.out.println("***********************************************");
//		System.out.println(cll);
		//cll.delete_first();
		cll.delete_last();
  //		System.out.println(cll);
  	cll.delete_by_position(2);
		System.out.println(cll);
		
	}
}
