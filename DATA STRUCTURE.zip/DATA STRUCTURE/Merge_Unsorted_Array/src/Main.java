
public class Main {

	public static void main(String[] args) {
		
		int arr []= new int [] {5,50,10,2,45,23,89,1};
		
		Merge.mergesort(arr,0,arr.length-1);
		Merge.display(arr);
	}
}
