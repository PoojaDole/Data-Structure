
public class Merge {

	
	/* in this code first we divide the array 
	 * divide into two parts
	 * 1. left to mid index;
	 * 2.mid+1 to right index;
	 * we sort this array 
	 *  but here we divided each part or block into single array then merge it
	 *  so each left array nd right array function call recursively
	 *  nd merge it*/
	
	public static void sort(int [] crr,int left,int right,int mid)
	{
		
		
		int n1=mid-left+1;
		int n2= right-(mid+1)+1;
		int arr[]=new int [n1];
		int brr[]=new int [n2];
	
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=crr[left+i];
		}
		for(int i=0;i<brr.length;i++)
		{
			brr[i]=crr[mid+1+i];
		}
		int i=0,j=0,k=left;
			
		while(i<arr.length && j<brr.length)
		{
			if(arr[i]<=brr[j])
			{
				crr[k]=arr[i];
				i++;  // 
				k++;
			}
			else
			{
				crr[k]=brr[j];
				k++;
				j++;
			}
		}
		if(i==arr.length)
		{
			while(j<brr.length)
			{
				crr[k]=brr[j];
				k++;
				j++;
			}
		}
		else
		{
			while(i<arr.length)
			{
				crr[k]=arr[i];
				k++;
				i++;
			}
		}
		
	}
	
	public static void mergesort(int crr[],int l,int r)
	{
		if(l<r)
		{
		
			int mid=(l+r)/2;//3
			
			mergesort(crr,l,mid);
			
			mergesort(crr,mid+1,r);
			
			sort(crr,l,r,mid);
			
		}
	}
	
	public static void display(int [] arr)
	{
	  System.out.println("****************** S O R T E D ************************************");
	  for (int i = 0; i < arr.length; i++) {
		System.out.print(arr[i]+"  ");
	  }
	  System.out.println();
	}
	
}
