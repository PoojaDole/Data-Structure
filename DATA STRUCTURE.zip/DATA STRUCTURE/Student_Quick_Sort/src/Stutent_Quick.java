
public class Stutent_Quick {

	public void qsort(Student arr[],int l,int h)
	{
		if(l<h)
		{
			int p=sort_Compare(arr,l,h);
			sort_Compare(arr,l,p-1);
			sort_Compare(arr,p+1,h);
		}
	}
	public int sort_Compare(Student [] arr,int lower,int higher)
	{
		int pivot=higher;
		int j=lower;
		int i=lower-1;
		
		while(j!=pivot)
		{
			if(arr[j].getAge()<arr[pivot].getAge())
			{
				i++;
				Student temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
			j++;
		}
		i++;
		Student temp=arr[i];
		arr[i]=arr[j];
		arr[j]=temp;
		
		return i;
	}
	public void display(Student [] arr)
	{

		
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]+" ,");
		}
		
	}
	
	
}
