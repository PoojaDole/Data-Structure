import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc =new Scanner(System.in);	
		System.out.println("Enter size of arrya");
		int s=sc.nextInt();
		Student st []=new Student[s]; 
		Stutent_Quick sk=new Stutent_Quick();
		
//		st[0]=new Student("Pooja ",52,'f');
//		st[1]=new Student("Pooja Dole ",2,'f');
//		st[2]=new Student("Pooja Dole p",20,'m');
		for(int i=0;i<st.length;i++)
		{
			System.out.println(" Enter name: ");
			sc.nextLine();
			String name=sc.nextLine();
			
			System.out.println(" Enter age: ");
			int age=sc.nextInt();
			
			System.out.println(" Enter gender");
			char g=sc.next().charAt(0);
			
			st[i]=new Student(name,age,g);
			
		}
		
		sk.qsort(st,0,st.length-1);
		sk.display(st);
	}
		
}
