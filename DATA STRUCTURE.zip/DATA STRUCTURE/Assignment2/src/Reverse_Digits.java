import java.util.Scanner;

public class Reverse_Digits {
	
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a number: ");
	int num=sc.nextInt();
	System.out.print("Reverse Digits: ");
	fun(num);
	sc.close();
	}

	public static int fun1(int num) {
		
		if(num==0)
			return 0;
		int a=num%10;
		System.out.print(a+" ");
		num=num/10;
		return fun1(num);
	}

	public static void fun(int num) {
		int a=num%10;
		if(num>0)
		{
			System.out.print(a+" ");
			num=num/10;
			fun(num);
		}
		
	}
}
