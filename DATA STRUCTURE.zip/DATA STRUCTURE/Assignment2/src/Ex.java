
public class Ex {

	public static void main(String[] args) {
		int arr[][]=new int[][] {1,1,4,4,2,3};
		check(arr);
	}

	private static void check(int[][] arr) {
		// TODO Auto-generated method stub
		
	}
}
/*



public static void throwException()

{

throw new RuntimeException();

Attempted: 0/5

4

Select an

5

6

8

As it is a runtime exception, thrown exceptions will be the IVM stack trace of exception

9

10

public static void testMethod() {

try {

System.out.println("Method not safe ");

throwException();

System.out.println("So throwing Exception");

}

finally {

System.out.println("Finally Done with Exceptions");

}

11

12

OUTPUT:

13

Method not safe

14

Caught Exception

15

16

17

OUTPUT:

18

Method not safe

public static void main(String[] args) {

try {

testMethod();

19 } catch (RuntimeException a) {

System.out.println("Caught Exception");

22

}

23

}

Caught Exception

Finally Done with Exceptions

20

21

OUTPUT:

+91 80471-89190

Need

*/