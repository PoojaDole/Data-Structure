
public class LinearSearch {

	public static void main(String[] args) {
		int arr[]=new int[] {10,56,88,1,36};
		int key=88;
		for (int i = 0; i < arr.length; i++) {
			 if(arr[i]==key)
			 {
				 System.out.println(" number is found at postion :"+(i+1));
				 break;
			 }
			
		}

	}

}
