import java.util.Scanner;
public class Series {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter last number to find sum of all numbers");
		int n=sc.nextInt();int i=0;
		int res=sum(n, i);
		System.out.println("Sum :"+res);
		sc.close();
	}
	public static int sum(int x,int a)
	{
		int res=0;
		System.out.print(a+"+");
		if(a<x)
		{
			a++;
			res=sum(x,a);
			res=res+a;
		}
		return res;
	}
}
