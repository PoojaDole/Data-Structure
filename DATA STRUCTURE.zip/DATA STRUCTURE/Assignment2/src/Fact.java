import java.util.Scanner;
public class Fact {

	public static void main(String[] args) {
	
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter a number");
		int num=sc.nextInt();
		sc.close();
		int res=fun(num);
		System.out.println("Factorial of "+num+ " :"+res);
	}
	public static int fun(int n)
	{
		if(n==0|| n==1)
			return 1;
		return (n*fun(n-1));
	}

}
