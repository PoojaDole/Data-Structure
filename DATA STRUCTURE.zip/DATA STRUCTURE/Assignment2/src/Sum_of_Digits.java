import java.util.Scanner;

public class Sum_of_Digits {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number");
		int num=sc.nextInt();
		int sum=0;
		int s=sum_of_digits(num,sum);
		System.out.println(s);
		sc.close();
	}
	public static int sum_of_digits(int n,int sum)
	{
		
		while(n>0)
		{
			int a=n%10;
			sum=sum+a;
			n=n/10;
			sum_of_digits(n,sum);
			
		}
	return sum;
	}

}
