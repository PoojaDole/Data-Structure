import java.util.Scanner;



public class Digits {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number: ");
		int num=sc.nextInt();
		System.out.print("DIGITS: ");
		fun(num);
		sc.close();
		}

	public static void fun(int num) {
		int a=num%10;
		if(num>0)
		{
			num=num/10;
			fun(num);
			System.out.print(a+" ");
		}
		
		
	}
}
