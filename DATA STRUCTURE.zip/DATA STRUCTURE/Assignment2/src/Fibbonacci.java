import java.util.Scanner;

public class Fibbonacci {
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter a number");
		int num=sc.nextInt();
		for(int i=num;i>0;i--)
		{
			int n=fun(i);
			System.out.print(n+" ");
			
		}
		sc.close();
	}
	public static int fun(int n)
	{
		if(n==0)
			return 0;

		if(n==1)
			return 1;
		
		int a=fun(n-1)+fun(n-2);
	
		return a;
	}
}
