
public class Hashing {
	Student arr [];
	int i=0;
	Hashing()
	{
		arr=new Student[5];
	}
	
	Hashing(int size)
	{
		arr=new Student[size];
	}
	public void insert(Student data)
	{
		int index=hashFunction(data.getMb_no());
		if(arr[index]==null)
		{
			arr[index]=data;
		}
		else
		{
			int flag=0;
			while(true)
			{
				if(index<arr.length)
				{
					if(arr[index]==null)
					{
						arr[index]=data;
						break;
					}
					index++;
				}
				
				
				else if(index >arr.length-1)
				{
					index=0;
					flag++;
					if(flag==2)
					{
						System.out.println(" Hash Array is full");
						break;
					}
					
				}
				
			}
			
		}
	}
	public int hashFunction(long mb_no) // 9146489215
	{int sum=0;
		i++;
		while(mb_no>0)
		{
			int num=(int)mb_no%100; //91464892%100
			mb_no=mb_no/100;   // 91464892
			sum=sum+num;
		}
		System.out.println("i: "+i+" index:"+(sum%arr.length));
		return (sum%arr.length);
	}
	public void remove(Student data)
	{
		int index=searchString(data);
		  //System.out.println("i: "+i+" remove index:"+index+" :"+(arr[index]));
		if(index>=0)
		{
			arr[index]=null;
		}
		
	}
	public int searchString(Student data)
	{
		int flag=0;
		int index=hashFunction(data.getMb_no());
		if(arr[index]==data)
		{
			return index;
		}
		else
		{
			while(true)
			{
			if(index<arr.length)
			{
			 
			  if(arr[index]==data)
			  {  return index;
			  		
			  }
			  else
				  index++;
			}
			else if(index >arr.length-1)
			{
				++flag;
				index=0;
				if(flag==2)
				{
					System.out.println(" Given data is not present");
					return -8;
				}
			}
			}
		}
		 
	}
	public String toString()
	{
		
		String str="";
		for(int i=0;i<arr.length;i++)
		{
			str+=" Arr["+i+"]:"+arr[i]+"\n ";
		}
		return str;
	}
	
}
