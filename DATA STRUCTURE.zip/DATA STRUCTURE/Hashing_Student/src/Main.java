
public class Main {
	
	public static void main(String[] args) {
		
		Hashing sh=new Hashing();
		Student s1=new Student(" Pooja",22,'f',9146489215L);
	   Student s2=new Student(" Prabandh",25,'M',9689861857L);
		Student s5=new Student(" Prabhu",25,'M',9689861857L);
		Student s3=new Student(" Pratik",26,'M',9145489215L);
		Student s4=new Student(" Suyog",22,'M',91464895665L);
		Student s6=new Student(" Sona",25,'f',91464569665L);
		sh.insert(s1);
		sh.insert(s2);
		sh.insert(s3);
		sh.insert(s4);
		sh.insert(s5);
		sh.insert(s6);
		sh.remove(s1);
		sh.remove(s2);
		sh.remove(s3);
		sh.remove(s4);
		sh.remove(s5);
		System.out.println(sh);
	}
}
