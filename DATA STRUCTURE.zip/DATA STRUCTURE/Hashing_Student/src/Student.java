
public class Student {
	private String name;
	private int age;
	private char gender;
	private long mb_no;
	
	
	public Student(String n,int a,char g,long no) {
		this.name=n;
		this.age=a;
		this.gender=g;
		this.mb_no=no;
	}
	

	
	public String toString() {

		String str="(#) "+this.name+ " " + this.age + " "+ this.gender+ " Mobile no: "+this.mb_no+"\n";
		return str ;
	}


	public long getMb_no() {
		return mb_no;
	}



	public void setMb_no(long mb_no) {
		this.mb_no = mb_no;
	}



	public String getName() {
		return this.name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getAge() {
		return this.age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public char getGender() {
		return this.gender;
	}


	public void setGender(char gender) {
		this.gender = gender;
	}
}
