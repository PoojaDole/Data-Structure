
public class Node {

	Employee data;
	Node next;
	
	
	Node()
	{
		this.data=null;
		this.next=null;
		
	}
	Node(Employee data)
	{
		this.data=data;
		this.next=null;
		
	}
	Node(Employee data,Node next)
	{
		this.data=data;
		this.next=next;
		
	}
	
	Node(Node next)
	{
		this.data=null;
		this.next=next;
		
	}
	
	
}
