
public class Linklist {

	private Node head;
	public Linklist() {
		this.head=null;
	}
	
	
	public Linklist(Node head) {
		this.head=head;
	}
	
	

    public  void insert(Employee data) 
    {
        Node newnode=new Node(data);
        if(head==null)
        {
            head=newnode;
        }
        else
        {
            newnode.next=head;
            head=newnode;

        }

    }
   
	public void append(Employee data)
    {
        Node newnode=new Node(data);
        if(head==null)
        {
            head=newnode;
        }
        else
        {
            Node it=head;
            while(it.next!=null)
            {
                it=it.next;
            }
            it.next=newnode;
            newnode.next=null;
        }
    }
    public void deletefirst()
    {
        if(head==null)
        {
            System.out.println("Linkedlist is empty");
        }
        else
        {
            if(head.next==null)
            {
                head=null;
            }
            else
            {
                Node it=head;
                head=it.next;
                it.next=null;
            }

        }
    }
    public void delete_last()
    {
        if(head==null)
        {
            System.out.println("linked list is empty");
        }
        else{
            if(head.next==null)
            {
                head=null;
            }
            else
            {
               Node it=head;
               while(it.next.next!=null)
               {
                   it=it.next;
               } 
               it.next=null;
            }
        }
    }
    public String toString()
    {
        String str="";
        if(head==null)
        {
            str=" Linked list is empty";
        }
        else
        {
        	Node it=head;
        	while(it!=null)
        	{
        		str+=it.data+" \n *********************************\n";
        		it=it.next;
        	}
        }
       return str; 
    }
	
}
