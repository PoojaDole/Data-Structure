
public class Main {

	public static void main(String[] args) {
		
		Linklist l=new Linklist();
		Employee e1=new Employee(1,80000,"pooja");
		Employee e2=new Employee(2,80500,"Ganesh");
		Employee e3=new Employee(3,50000,"Gauri");
		l.insert(e1);
		l.append(e2);
		l.delete_last();
		l.delete_last();
		l.append(e3);
		System.out.println(l);
	}
}
