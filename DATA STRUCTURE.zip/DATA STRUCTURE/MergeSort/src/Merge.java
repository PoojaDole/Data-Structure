
public class Merge {

	public int [] merge_sort(int [] arr,int [] brr)
	{
		int s= arr.length+brr.length;
		int crr []=new int [s];
		
		int i=0,j=0,k=0;
		while(i<arr.length && j<brr.length)
		{
			if(arr[i]<=brr[j])
			{
				crr[k]=arr[i];
				i++;  // 
				k++;
			}
			else
			{
				crr[k]=brr[j];
				k++;
				j++;
			}
		}
		if(i==arr.length)
		{
			while(j<brr.length)
			{
				crr[k]=brr[j];
				k++;
				j++;
			}
		}
		else
		{
			while(i<arr.length)
			{
				crr[k]=arr[i];
				k++;
				i++;
			}
		}
		
		return crr;
		
	}
	
	public void display(int [] arr)
	{
	  System.out.println("****************** S O R T E D ************************************");
	  for (int i = 0; i < arr.length; i++) {
		System.out.print(arr[i]+"  ");
	  }
	  System.out.println();
	}

}
