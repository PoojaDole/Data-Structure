
public class Main {

	public static void main(String[] args) {
		
		Merge mg=new Merge();
		int []arr=new int [] { 4,10,20,58,70};

		int []brr=new int [] { 24,30,40,59,80,100};
		
		int [] crr=new int [arr.length+brr.length];
		crr=mg.merge_sort(arr,brr);
		mg.display(crr);
		
	}

	

	

	
	
}
