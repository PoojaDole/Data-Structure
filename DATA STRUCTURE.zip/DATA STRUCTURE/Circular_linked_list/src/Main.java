
public class Main {

	public static void main(String[] args) {
		
		CircularLL cll=new CircularLL();
		cll.insert(10);
		cll.insert(20);
		cll.append(30);
		System.out.println(cll);
		cll.insert(50);
		cll.append(100);
		cll.insert_by_position(80, 3);
		System.out.println(cll);
		cll.delete_first();
		cll.delete_last();
		System.out.println(cll);
		cll.delete_by_position(2);
		System.out.println(cll);
		// all correct
	}
}
