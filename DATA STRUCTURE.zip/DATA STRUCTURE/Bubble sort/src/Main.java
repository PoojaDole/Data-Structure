
public class Main {

	public static void main(String[] args) {
		
		int arr[]=new int[] {11,23,44,12,78,34,23};
		Bubble b1=new Bubble();
		int c=b1.Bubble_sort(arr);
		System.out.println(c);
		b1.print(arr);
	
		
	}
}
