import java.util.Scanner;

public class Stackmain {
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a size of stack");
		int size=sc.nextInt();
		Stack stk1=new Stack(size);
		Student s1=new Student("Pooja",21,'f');
		Student s2=new Student("Monika",22,'f');
		Student s3=new Student("Rani",33,'f');
		
		stk1.push(s1);
		stk1.push(s2);
		System.out.println("enter a size of stack");
		int s=sc.nextInt();
		Stack stk2=new Stack(s);
		stk2.push(s1);
		stk2.push(s2);
		stk2.push(s3);
		
	
	}
}
